import serial
from binascii import hexlify
import serial.tools.list_ports as list_ports
BAUD_RATE = 9600

print([comport.device for comport in list_ports.comports()])

ser = serial.Serial('/dev/ttyUSB0', BAUD_RATE)

while True:
    print("put your weight here [0.1, 999999.9]: ")
    weight = input()
    print('print template number [1, 2]')
    template = input()
    try:
        weight = float(weight)
        template = int(template)
        w = weight
        print('your number ' + str(weight) + ' is correct!')
        digits = 0
        while(w > 0):
            w = w // 10
            digits += 1
        if(weight < 0.1 or weight > 999999.9 or template > 2 or template < 1):
            print("number out of bounds")
        else:
            s = "ww"
            zeros = 6 - digits
            while zeros > 0:
                s = s + "0"
                zeros -= 1
            if template == 1:
                s = s + str(weight) + "kg\r\n"
            else:
                s = '=' + str(int(weight))[::-1] # + "\r\n"
            s = s.encode()
            #s = bytearray(b'\x77\x77\x30\x30\x30\x31\x39\x32\x2e\x36\x6b\x67\x0d\x0a')
            s = bytearray(b'\x3d\x30\x36\x33\x30\x31\x30\x2d')
            print('package ' + str(s))
            print('sending...')
            ser.write(s)
    except ValueError:
        print("Please, put float weight number [0.1, 999999.9]")
        print("Please, put int template number [1, 2]")
ser.close()
