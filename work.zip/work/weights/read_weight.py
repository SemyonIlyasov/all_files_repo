import serial
import serial.tools.list_ports as list_ports
import binascii
import weight_by_template
import time

BAUD_RATE = 9600

device = '/dev/ttyUSB0'

print([comport.device for comport in list_ports.comports()])

ser = serial.Serial(device, BAUD_RATE)

parser =  weight_by_template.weight_by_template(conf_path=None)
parser.get_template()
prevres = 0
while True:

	res = parser.get_weight(ser=ser)
	print('result : ', res)
	if(res != prevres):
		print('print to file')
		resfile = open('/home/www/AutoFarm/weight.txt', 'w')
		resfile.write(str(res))
		prevres = res
		resfile.close()
ser.close()
