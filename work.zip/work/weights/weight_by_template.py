import os
import serial
import re
import binascii
from os.path import exists

class weight_by_template:
	# if you want to add 1 more template add template number to self.tempalates
	#  and add method template<N> as template1 to if construction in get_weight

	# if you want to add configuration add it to if construction in parse_config method

	def __init__(self, conf_path=None):
		self.conf_path = conf_path
		self.template = None
		self.default_conf_path = './weight_config.txt'
		self.templates = [1,2]

	def get_template(self):
		if(self.conf_path == None or (not exists(self.conf_path) and not exists(self.default_conf_path))):
			print('[WARNING] config file does not exist or not stated! Default config file will be used.')
			self.conf_path = self.default_conf_path
			if (not exists(self.default_conf_path)):
				f = open(self.conf_path, "w")
				f.write("template: 1")
				f.close()
		self.parse_config()

	def parse_config(self):
		config = open(self.conf_path, "r")
		all_strings = config.readlines()
		for s in all_strings:
			conf_string = s.replace(' ', '').lower().split(':')
			# conf_string example: template:1
			if(conf_string[0] == 'template'):
				try:
					self.template = int(conf_string[1])
				except ValueError:
					print('[ERROR] bad configuration value (ValueError)')
					exit()
				if self.template not in self.templates:
					print('[ERROR] this template ' + str(self.template) + ' does not exist')
					exit()
			else:
				print('[ERROR] this configuration ' + str(conf_string[0]) + ' does not exist!')
				exit()

	def get_weight(self, bytestring=None, ser=None):
		if (bytestring==None and ser==None):
			print('[ERROR] not enougth arguments!')
			exit()

		if(self.template == 1):
			return self.template1(bytestring, ser)
		elif(self.template == 2):
			return self.template2(bytestring, ser)
		else:
			print('[ERROR] this template doe not exist!')
			exit()

	def template1(self,bytestring=None, ser=None):
		if bytestring != None:
			return bytestring
		else:
			L = 28
			data = str(binascii.unhexlify(ser.read(L)))
			data = data[:len(data) - 5]
			float_pattern = ['\r', '\n', '0','1','2','3','4','5','6','7','8','9','.','-']
			trash_pattern = '[' + ''.join(str(re.sub(('[' + ''.join(float_pattern) + ']'), '', data))) + ']'
			filtered_data = re.sub(trash_pattern, '', data)
			return float(filtered_data)


	def template2(self, bytestring=None, ser=None):
		if bytestring != None:
			return bytestring
		else:
			L = 18
			data = str(binascii.unhexlify(ser.read(L)))
			float_pattern = ['0','1','2','3','4','5','6','7','8','9','.','-']
			trash_pattern = '[' + ''.join(str(re.sub(('[' + ''.join(float_pattern) + ']'), '', data))) + ']'
			filtered_data = re.sub(trash_pattern, '', data)
			filtered_data = filtered_data[::-1]
			filtered_data = filtered_data[:-1] + '.' + filtered_data[-1:]
			return float(filtered_data)
